from django.shortcuts import render

# Create your views here.

from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.db.models import ObjectDoesNotExist
from django.core.paginator import Paginator #import Paginator
from django.contrib.auth.decorators import login_required

from .forms import *
from .models import *

@login_required
def index(request):
	return html(request, "index")


def html(request, filename):
	context = {"filename": filename, "collapse": ""}
	
	if request.user.is_anonymous and filename != "login":
		return redirect("/login.html")
		
	if filename == "logout":
		logout(request)
		return redirect("/")
		
	if filename == "login" and request.method == "POST":
		username = request.POST.get("username")
		password = request.POST.get("password")
		try:
			if "@" in username:
				user = User.objects.get(email=username)
			else:
				user = User.objects.get(username=username)
			user = authenticate(request, username=user.username, password=password)
			if user is not None:
				login(request, user)
				return redirect("/")
			else:
				context["error"] = "Wrong password"
		except ObjectDoesNotExist:
			context["error"] = "User not found"
			
		print("login")
		print(username, password)
	print(filename, request.method)
	if filename in ["buttons", "cards"]:
		context["collapse"] = "components"

	if filename in ["utilities-color", "utilities-border", "utilities-animation", "utilities-other"]:
		context["collapse"] = "utilities"

	if filename in ["404", "blank"]:
		context["collapse"] = "pages"
		
	return render(request, f"{filename}.html", context=context)

@login_required
def CustomerList_view(request):
	form = CustomerForm(request.POST or None, request.FILES or None)
	
	if form.is_valid():
		form.save()
		return redirect("/customers/")	
	
	customers = Customer.objects.all()
	context = {
		'customers': customers,
		'form': form,
		'collapse': 'Sales'
	}

	return render(request=request, template_name="customerList.html", context=context)

@login_required
def EmployeeList_view(request):
	form = EmployeeForm(request.POST or None, request.FILES or None)
	
	if form.is_valid():
		form.save()
		return redirect("/employees/")	
	employees = Employee.objects.all()
	context = {
		'form': form,
		'employees': employees,
		'collapse': 'HR'
	}

	return render(request=request, template_name="employeeList.html", context=context)

@login_required
def ItemList_view(request):
	form = ItemForm(request.POST or None, request.FILES or None)
	
	if form.is_valid():
		form.save()
		return redirect("/items/")	

	items = Item.objects.all()
	context = {
		'form': form,
		'items': items,
		'collapse': 'Items'
	}

	return render(request=request, template_name="itemList.html", context=context)

@login_required
def IvaList_view(request):
	form = IvaForm(request.POST or None, request.FILES or None)
	
	if form.is_valid():
		form.save()
		return redirect("/iva/")	

	ivas = Iva.objects.all() 
	context = {
		'form': form,
		'ivas': ivas,
		'collapse': 'Settings'
	}
	return render(request=request, template_name="ivaList.html", context=context)

@login_required
def PositionList_view(request):
	form = PositionForm(request.POST or None, request.FILES or None)
	
	if form.is_valid():
		form.save()
		return redirect("/positions/")	

	positions = Position.objects.all()
	context = {
		'form': form,
		'positions': positions,
		'collapse': 'HR'
	}

	return render(request=request, template_name="positionList.html", context=context)

@login_required
def TitleList_view(request):
	form = TitleForm(request.POST or None, request.FILES or None)
	
	if form.is_valid():
		form.save()
		return redirect("/titles/")	

	titles = Title.objects.all() 
	context = {
		'form': form,
		'titles': titles,
		'collapse': 'Settings'
	}
	return render(request=request, template_name="titleList.html", context=context)

@login_required
def WarehouseList_view(request):
	form = WarehouseForm(request.POST or None, request.FILES or None)
	
	if form.is_valid():
		form.save()
		return redirect("/warehouses/")	

	warehouses = Warehouse.objects.all()
	context = {
		'form': form,
		'warehouses': warehouses,
		'collapse': 'Items'
	}

	return render(request=request, template_name="warehouseList.html", context=context)

@login_required
def SupplierList_view(request):

	form = SupplierForm(request.POST or None, request.FILES or None)
	
	if form.is_valid():
		form.save()
		return redirect("/suppliers/")	

	suppliers = Supplier.objects.all()
	context = {
		'form': form,
		'suppliers': suppliers,
		'collapse': 'Payments'
	}

	return render(request=request, template_name="supplierList.html", context=context)

@login_required
def CustomerInfo_view(request, customer_id):
	
	customer = Customer.objects.get(id=customer_id)
	context = {
		'customers': customer,
		'collapse': 'Sales'
	}

	return render(request=request, template_name="customerInfo.html", context=context)

@login_required
def EmployeeInfo_view(request, employee_id):
	
	employee = Employee.objects.get(id=employee_id)
	context = {
		'employees': employee,
		'collapse': 'HR'
	}

	return render(request=request, template_name="employeeInfo.html", context=context)

@login_required
def ItemInfo_view(request, item_id):
	
	item = Item.objects.get(id=item_id)
	context = {
		'items': item,
		'collapse': 'Items'
	}

	return render(request=request, template_name="ItemInfo.html", context=context)

@login_required
def PositionInfo_view(request, position_id):
	
	position = Position.objects.get(id=position_id)
	context = {
		'positions': position,
		'collapse': 'HR'
	}

	return render(request=request, template_name="positionInfo.html", context=context)

@login_required
def SupplierInfo_view(request, supplier_id):
	
	supplier = Supplier.objects.get(id=supplier_id)
	context = {
		'suppliers': supplier,
		'collapse': 'Payments'
	}

	return render(request=request, template_name="supplierInfo.html", context=context)

@login_required
def WarehouseInfo_view(request, warehouse_id):
	
	warehouse = Warehouse.objects.get(id=warehouse_id)
	context = {
		'warehouses': warehouse,
		'collapse': 'Items'
	}

	return render(request=request, template_name="warehouseInfo.html", context=context)

@login_required
def CustomerNew_view(request):
    # create object of form
	form = CustomerForm(request.POST or None, request.FILES or None)
	
	if form.is_valid():
		form.save()
		return redirect("/customers/")	

	context = {
		'form': form,
		'collapse': 'Sales'
	}

	return render(request, 'customerNew.html', context=context)

@login_required
def EmployeeNew_view(request):
    # create object of form
	form = EmployeeForm(request.POST or None, request.FILES or None)
	
	if form.is_valid():
		form.save()
		return redirect("/employees/")	

	context = {
		'form': form,
		'collapse': 'HR'
	}

	return render(request, 'employeeNew.html', context=context)

@login_required
def PositionNew_view(request):
    # create object of form
	form = PositionForm(request.POST or None, request.FILES or None)
	
	if form.is_valid():
		form.save()
		return redirect("/positions/")	

	context = {
		'form': form,
		'collapse': 'HR'
	}

	return render(request, 'positionNew.html', context=context)

@login_required
def ItemNew_view(request):
    # create object of form
	form = ItemForm(request.POST or None, request.FILES or None)
	
	if form.is_valid():
		form.save()
		return redirect("/items/")	

	context = {
		'form': form,
		'collapse': 'Items'
	}

	return render(request, 'itemNew.html', context=context)

@login_required
def TitleNew_view(request):

	form = TitleForm(request.POST or None, request.FILES or None)
	if form.is_valid():
		form.save()
		return redirect("/titles/")	

	context = {
		'form': form,
		'collapse': 'Settings'
	}

	return render(request, 'titleNew.html', context=context)

@login_required
def SupplierNew_view(request):
    # create object of form
	form = SupplierForm(request.POST or None, request.FILES or None)
	
	if form.is_valid():
		form.save()
		return redirect("/suppliers/")	

	context = {
		'form': form,
		'collapse': 'Payments'
	}

	return render(request, 'supplierNew.html', context=context)

@login_required
def WarehouseNew_view(request):
    # create object of form
	form = WarehouseForm(request.POST or None, request.FILES or None)
	
	if form.is_valid():
		form.save()
		return redirect("/warehouses/")	

	context = {
		'form': form,
		'collapse': 'Items'
	}

	return render(request, 'warehouseNew.html', context=context)

@login_required
def CustomerEdit_view(request, customer_id):
    # Edit object of form
	customer = Customer.objects.get(id=customer_id)

	form = CustomerForm(request.POST or None, instance = customer)
	
	if request.POST and form.is_valid():
		form.save()
		return redirect("/customers/")	

	context = {
		'form': form,
		'collapse': 'Sales'
	}

	return render(request, 'customerEdit.html', context=context)

@login_required
def EmployeeEdit_view(request, employee_id):
    # Edit object of form
	employee = Employee.objects.get(id=employee_id)

	form = EmployeeForm(request.POST or None, instance = employee)
	
	if request.POST and form.is_valid():
		form.save()
		return redirect("/employees/")	

	context = {
		'form': form,
		'collapse': 'HR'
	}

	return render(request, 'employeeEdit.html', context=context)

@login_required
def ItemEdit_view(request, item_id):
    # Edit object of form
	item = Item.objects.get(id=item_id)

	form = ItemForm(request.POST or None, instance = item)
	
	if request.POST and form.is_valid():
		form.save()
		return redirect("/items/")	

	context = {
		'form': form,
		'collapse': 'Items'
	}

	return render(request, 'itemEdit.html', context=context)

@login_required
def PositionEdit_view(request, position_id):
    # Edit object of form
	position = Position.objects.get(id=position_id)

	form = PositionForm(request.POST or None, instance = position)
	
	if request.POST and form.is_valid():
		form.save()
		return redirect("/positions/")	

	context = {
		'form': form,
		'collapse': 'HR'
	}

	return render(request, 'positionEdit.html', context=context)

@login_required
def SupplierEdit_view(request, supplier_id):
    # Edit object of form
	supplier = Supplier.objects.get(id=supplier_id)

	form = SupplierForm(request.POST or None, instance = supplier)
	
	if request.POST and form.is_valid():
		form.save()
		return redirect("/suppliers/")	

	context = {
		'form': form,
		'collapse': 'Purchases'
	}

	return render(request, 'supplierEdit.html', context=context)

@login_required
def WarehouseEdit_view(request, warehouse_id):
    # Edit object of form
	warehouse = Warehouse.objects.get(id=warehouse_id)

	form = WarehouseForm(request.POST or None, instance = warehouse)
	
	if request.POST and form.is_valid():
		form.save()
		return redirect("/warehouses/")	

	context = {
		'form': form,
		'collapse': 'Items'
	}

	return render(request, 'warehouseEdit.html', context=context)

@login_required
def CustomerBulkAction_view(request, id=None):	

	if request.method == 'POST':
		id_list = request.POST.getlist('instance')
		# This will submit an array of the value attributes of all the
		# checkboxes that have been checked, that is an array of {{obj.id}}

		# Now all that is left is to iterate over the array fetch the   
		# object with the ID and delete it. 
		for customer_id in id_list:
			Customer.objects.get(id=customer_id).delete()
		# maybe in some other cases it is not possible to delete an object
		# as it may be foreigh key to another object
		# in those cases it is better to issue a warning message

	return redirect('CustomerList')
	
@login_required
def EmployeeBulkAction_view(request, id=None):	

	if request.method == 'POST':
		id_list = request.POST.getlist('instance')
		# This will submit an array of the value attributes of all the
		# checkboxes that have been checked, that is an array of {{obj.id}}

		# Now all that is left is to iterate over the array fetch the   
		# object with the ID and delete it. 
		for employee_id in id_list:
			Employee.objects.get(id=employee_id).delete()
		# maybe in some other cases it is not possible to delete an object
		# as it may be foreigh key to another object
		# in those cases it is better to issue a warning message

	return redirect('EmployeeList')

@login_required
def ItemBulkAction_view(request, id=None):	

	if request.method == 'POST':
		id_list = request.POST.getlist('instance')
		# This will submit an array of the value attributes of all the
		# checkboxes that have been checked, that is an array of {{obj.id}}

		# Now all that is left is to iterate over the array fetch the   
		# object with the ID and delete it. 
		for item_id in id_list:
			Item.objects.get(id=item_id).delete()
		# maybe in some other cases it is not possible to delete an object
		# as it may be foreigh key to another object
		# in those cases it is better to issue a warning message

	return redirect('ItemList')

@login_required
def IvaBulkAction_view(request, id=None):	

	if request.method == 'POST':
		id_list = request.POST.getlist('instance')
		# This will submit an array of the value attributes of all the
		# checkboxes that have been checked, that is an array of {{obj.id}}

		# Now all that is left is to iterate over the array fetch the   
		# object with the ID and delete it. 
		for iva_id in id_list:
			Iva.objects.get(id=iva_id).delete()
		# maybe in some other cases it is not possible to delete an object
		# as it may be foreigh key to another object
		# in those cases it is better to issue a warning message

	return redirect('IvaList')

@login_required
def PositionBulkAction_view(request, id=None):	

	if request.method == 'POST':
		id_list = request.POST.getlist('instance')
		# This will submit an array of the value attributes of all the
		# checkboxes that have been checked, that is an array of {{obj.id}}

		# Now all that is left is to iterate over the array fetch the   
		# object with the ID and delete it. 
		for position_id in id_list:
			Position.objects.get(id=position_id).delete()
		# maybe in some other cases it is not possible to delete an object
		# as it may be foreigh key to another object
		# in those cases it is better to issue a warning message

	return redirect('PositionList')

@login_required
def SupplierBulkAction_view(request, id=None):	

	if request.method == 'POST':
		id_list = request.POST.getlist('instance')
		# This will submit an array of the value attributes of all the
		# checkboxes that have been checked, that is an array of {{obj.id}}

		# Now all that is left is to iterate over the array fetch the   
		# object with the ID and delete it. 
		for supplier_id in id_list:
			Supplier.objects.get(id=supplier_id).delete()
		# maybe in some other cases it is not possible to delete an object
		# as it may be foreigh key to another object
		# in those cases it is better to issue a warning message

	return redirect('SupplierList')

@login_required
def TitleBulkAction_view(request, id=None):	

	if request.method == 'POST':
		id_list = request.POST.getlist('instance')
		# This will submit an array of the value attributes of all the
		# checkboxes that have been checked, that is an array of {{obj.id}}

		# Now all that is left is to iterate over the array fetch the   
		# object with the ID and delete it. 
		for title_id in id_list:
			Title.objects.get(id=title_id).delete()
		# maybe in some other cases it is not possible to delete an object
		# as it may be foreigh key to another object
		# in those cases it is better to issue a warning message

	return redirect('TitleList')

@login_required
def WarehouseBulkAction_view(request, id=None):	

	if request.method == 'POST':
		id_list = request.POST.getlist('instance')
		# This will submit an array of the value attributes of all the
		# checkboxes that have been checked, that is an array of {{obj.id}}

		# Now all that is left is to iterate over the array fetch the   
		# object with the ID and delete it. 
		for warehouse_id in id_list:
			Warehouse.objects.get(id=warehouse_id).delete()
		# maybe in some other cases it is not possible to delete an object
		# as it may be foreigh key to another object
		# in those cases it is better to issue a warning message

	return redirect('WarehouseList')


document.addEventListener('DOMContentLoaded', function() {
    $('#customerTable').DataTable({
        language: {
            url: '//cdn.datatables.net/plug-ins/1.11.3/i18n/pt_pt.json'
        },
        "columnDefs": [{
            "targets": [0, 4],
            "orderable": false,
            "width": "16%"
        }]
    });
    $(".clickable-row, #customerTable").click(  function (event) {
        $(document).find('h4#form-modal-title').text("Editar Cliente ");

        $("#clientModal").modal('show');

        //alert($(this).data('href'));
        //setTimeout(function() { $("#clientModal").modal('show'); }, 1000);
        //window.location = $(this).data('href');

    });
    $("#addClientButton").click(  function() {
        $(document).find('h4#form-modal-title').text("Adicionar Cliente");
    });
    $('#employeeTable').DataTable( {
        language: {
            url: '//cdn.datatables.net/plug-ins/1.11.3/i18n/pt_pt.json'
        },
        "columnDefs": [ { 
            "targets": [0,4],
            "orderable": false,
            "width": "16%"
        } ]
    } );
    $(".clickable-row, #employeeTable").click(function() {
        $(document).find('h4#form-modal-title').text("Editar Funcionário");
        $("#employeeModal").modal('show');
    });
    $("#addEmployeeButton").click(  function() {
        $(document).find('h4#form-modal-title').text("Adicionar Funcionário");
    });
    $('#itemTable').DataTable( {
        language: {
            url: '//cdn.datatables.net/plug-ins/1.11.3/i18n/pt_pt.json'
        },
        "columnDefs": [ { 
            "targets": [0,4],
            "orderable": false,
            "width": "16%"
        } ]
    } );
    $(".clickable-row, #itemTable").click(function() {
        $(document).find('h4#form-modal-title').text("Editar Item");
        $("#itemModal").modal('show');
    });
    $("#addItemButton").click(  function() {
        $(document).find('h4#form-modal-title').text("Adicionar Item");
    });
    $('#positionTable').DataTable( {
        language: {
            url: '//cdn.datatables.net/plug-ins/1.11.3/i18n/pt_pt.json'
        }
    } );
    $(".clickable-row, #positionTable").click(function() {
        $(document).find('h4#form-modal-title').text("Editar Cargo");
        $("#positionModal").modal('show');
    });
    $("#addPositionButton").click(  function() {
        $(document).find('h4#form-modal-title').text("Adicionar Cargo");
    });
    $('#supplierTable').DataTable( {
        language: {
            url: '//cdn.datatables.net/plug-ins/1.11.3/i18n/pt_pt.json'
        },
        "columnDefs": [ { 
            "targets": [0,4],
            "orderable": false,
            "width": "16%"
        } ]
    } );
    $(".clickable-row, #supplierTable").click(function() {
        $(document).find('h4#form-modal-title').text("Editar Fornecedor");
        $("#supplierModal").modal('show');
    });
    $("#addSupplierButton").click(  function() {
        $(document).find('h4#form-modal-title').text("Adicionar Fornecedor");
    });
    $('#warehouseTable').DataTable( {
        language: {
            url: '//cdn.datatables.net/plug-ins/1.11.3/i18n/pt_pt.json'
        },
        "columnDefs": [ { 
            "targets": [0,3],
            "orderable": true,
            "width": "16%"
        } ]
    } );
    $(".clickable-row, #warehouseTable").click(function() {
        $(document).find('h4#form-modal-title').text("Editar Armazém");
        $("#warehouseModal").modal('show');
    });
    $("#addWarehouseButton").click(  function() {
        $(document).find('h4#form-modal-title').text("Adicionar Armazém");
    });
}); 




from django.db import models
from django_countries.fields import *
from phonenumber_field.modelfields import PhoneNumberField

#from django.contrib.localflavor.pt.models import USStateField

# Create your models here.

class Customer(models.Model):
	GENDER_MALE = 0
	GENDER_FEMALE = 1
	GENDER_OTHER = 3
	GENDER_COMPANY = 4
	GENDER_CHOICES = [
		(GENDER_COMPANY, 'Empresa'),
		(GENDER_MALE, 'Masculino'), 
		(GENDER_FEMALE, 'Feminino'),
		(GENDER_OTHER, 'Outro')
		]		
	title = models.ForeignKey("Title", null=True, on_delete=models.SET_NULL, default=1)
	gender = models.IntegerField(choices=GENDER_CHOICES, default=0)
	name = models.CharField(max_length=200, blank=False, unique=False)
	address = models.TextField(null=True, blank=True)
	zipCode =  models.CharField(max_length=8, null=True, blank=True)
	city = models.CharField(max_length=200, null=True, blank=True)
	country = CountryField(null=True, blank=True)
	website = models.URLField(max_length=200, blank=True, null=True)
	taxNumber = models.CharField(max_length=12, blank=True, null=True)
	dateOfBirth = models.DateField(blank=True, null=True)
	phone = PhoneNumberField(blank=True, null=True)
	contactByEmail = models.BooleanField(blank=False, null=False, default=False)
	contactBySMS = models.BooleanField(blank=False, null=False, default=False)
	contactByPhone = models.BooleanField(blank=False, null=False, default=False)

class Employee(models.Model):
	GENDER_MALE = 0
	GENDER_FEMALE = 1
	GENDER_OTHER = 3
	GENDER_COMPANY = 4
	GENDER_CHOICES = [
		(GENDER_COMPANY, 'Empresa'),
		(GENDER_MALE, 'Masculino'), 
		(GENDER_FEMALE, 'Feminino'),
		(GENDER_OTHER, 'Outro')
		]		
	title = models.ForeignKey("Title", null=True, on_delete=models.SET_NULL, default=1)
	gender = models.IntegerField(choices=GENDER_CHOICES, default=0)
	name = models.CharField(max_length=200, blank=False, unique=False)
	address = models.TextField(null=True, blank=True)
	zipCode =  models.CharField(max_length=8, null=True, blank=True)
	city = models.CharField(max_length=200, null=True, blank=True)
	country = CountryField(null=True, blank=True)
	taxNumber = models.CharField(max_length=12, blank=True, null=True)
	dateOfBirth = models.DateField(blank=True, null=True)
	phone = PhoneNumberField(blank=True, null=True)
	contactByEmail = models.BooleanField(blank=False, null=False, default=False)
	contactBySMS = models.BooleanField(blank=False, null=False, default=False)
	contactByPhone = models.BooleanField(blank=False, null=False, default=False)

class Item(models.Model):
	CATEGORY_PRODUCT = 0
	CATEGORY_SERVICE = 1
	CATEGORY_CHOICES = [
		(CATEGORY_PRODUCT, 'Produto'),
		(CATEGORY_SERVICE, 'Serviço')
		]
	category = models.IntegerField(choices=CATEGORY_CHOICES, default=0)
	iva = models.ForeignKey("Iva",null=True, blank=False, on_delete=models.SET_NULL)
	"""unit_Id = models.ForeignKey(Unit, on_delete=models.CASCADE)"""
	cost = models.FloatField(null=True, blank=True)
	description = models.TextField(null=True, blank=True)
	external_Ref = models.CharField(max_length=12, blank=True, null=True)
	weight = models.FloatField(null=True, blank=True)
	origin = CountryField(null=True, blank=True)
	notes = models.TextField(null=True, blank=True)
	supplier_Id = models.ForeignKey("Supplier", null=True, blank=False, on_delete=models.SET_NULL)
	"""family = models.ForeignKey(Family, null=True, blank=False, on_delete=models.SET_NULL)"""
	pvp = models.FloatField(null=True, blank=True)

class Iva(models.Model):
	rate = models.IntegerField(null=False, blank=False)
	name = models.CharField(max_length=200, blank=False, unique=True)

	def __str__(self):
		return self.name + " (" + str(self.rate) + "%)"

class Position(models.Model):
	name = models.CharField(max_length=200, blank=False, unique=False)
	description = models.TextField(null=True, blank=True)

class Warehouse(models.Model):
	name = models.CharField(max_length=200, blank=False, unique=False)
	description = models.TextField(null=True, blank=True)
	address = models.TextField(null=True, blank=True)

class Store(Warehouse):
    pass

class External_Warehouse(Warehouse):
	pass

class Movement(models.Model):
	product_Id = models.ForeignKey(Item, null=True, blank=False, on_delete=models.SET_NULL)
	quantity = models.FloatField(null=False, blank=False)
	source = models.ForeignKey(External_Warehouse, null=True, on_delete=models.SET_NULL)
	destination = models.ForeignKey(Store, null=True, on_delete=models.SET_NULL)
	cost = models.FloatField(null=False, blank=False)
	document_Id = models.TextField(null=False, blank=False)

class Supplier(models.Model):
	name = models.CharField(max_length=200, blank=False, unique=False)
	address = models.TextField(null=True, blank=True)
	zipCode =  models.CharField(max_length=8, null=True, blank=True)
	city = models.CharField(max_length=200, null=True, blank=True)
	country = CountryField(null=True, blank=True)
	website = models.URLField(max_length=200, blank=True, null=True)
	taxNumber = models.CharField(max_length=12, blank=True, null=True)
	dateOfBirth = models.DateField(blank=True, null=True)
	phone = PhoneNumberField(blank=True, null=True)
	contactByEmail = models.BooleanField(blank=False, null=False, default=False)
	contactBySMS = models.BooleanField(blank=False, null=False, default=False)
	contactByPhone = models.BooleanField(blank=False, null=False, default=False)

	def __str__(self):
		return self.name
	
class Title(models.Model):
	title = models.CharField(max_length=10)
	def __str__(self):
		return self.title

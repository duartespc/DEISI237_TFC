# nucleos

## Install
* remove python2 (if applicable)
* install python3
* install python3-pip
* install pipenv
Then on the project folder run
```
pipenv shell
pip install -r requirements.txt
python manage.py runserver
```
